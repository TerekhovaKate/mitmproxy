from setuptools import setup, find_packages
import ea_mitmproxy

setup(
    name='ea_mitmproxy',
    version=ea_mitmproxy.__version__,
    description='Proxy for EA services',
    url='https://github.comcast.com/eapy/ea_mitmproxy',
    author='Joshua Brummet',
    entry_points={
        'console_scripts': [
            'ea-proxy = ea_mitmproxy.app:main',
        ],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
    ],

    keywords='rest restful api flask swagger openapi flask-restplus ea sspc proxy',

    packages=find_packages(),

    install_requires=['flask-restplus', 'emoji', 'flask_cors', 'coloredlogs', 'mitmproxy', 'Flask-Testing', 'flask',
                      'requests', 'pytest']
)