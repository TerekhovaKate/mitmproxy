# EA Man in the Middle Proxy

## Installation
```
> python3 -m venv env
> source env/bin/activate
> pip3 install -e . --extra-index-url http://10.144.235.134:9839/ --trusted-host 10.144.235.134
```

## Running
```
> python3 ea_mitmproxy/app.py
```

## Connecting to proxy browser (HTTP / HTTPS)

The proxy needs to be configured in network settings before running the proxy.
The best way to get the needed certificate is running `brew install mitmproxy`
Installing mitmproxy as a command line tool is beneficial in sniffing all the traffic
So you have a idea on what requests you want to intervene and manipulate.

Once mitmproxy is installed go ahead an run `mitmproxy` in the commandline. 
You will see the terminal GUI appear. Feel free to play around or go ahead and close the GUI 
by ^C. 

Now you can go ahead and pull up ~/.mitmproxy in your finder or terminal. You will see a bunch of certificates appear.
This is because mitmproxy generates these certificates automatically the first time you run the proxy.

Please look at the following documentation for for information.
https://docs.mitmproxy.org/stable/concepts-certificates/
#### MacOsx

1. Open keychain access.
2. Open the generated certificates in a finder window.
3. Click and drag `mitmproxy-ca-cert.pem` into the keychain access under the login keychain.
4. Right click on the the new certificate in the keychain window and select more info.
5. Go ahead and allow the new certificate to `trust all`.
6. Click on wifi
7. Open up network preferences
8. Select "Advanced" under the wifi you're connected too
9. Click on the title "proxies"
10. Click to enable "web proxies (HTTP)"
11. Under "Web proxy server", host: 0.0.0.0, port: 3030 (default)
12. Click to enable "web proxies (https)"
13. Under "Web proxy server", host: 0.0.0.0, port: 3030 (default)
14. Click "Ok"
15. Select Apply


## Connecting to proxy iOS / Android

Connecting to the proxy on a mobile device requires the proxy to be up and running on your local box which the mobile
device will route all its traffic to.

To start please launch the proxy by either `python3 ea_mitmproxy/app.py` or `mitmproxy` in the command line.

Now get your hubs IP address. This can be found by either `ifconfig` or looking at your network settings.

Go to your mobile device and select on the wifi network you're connected to. Remember this has to be the same network
the hub is connected to which is currently running the proxy.

Select *Configure Proxy* in the `http proxy` settings for the wifi connection. 

Select *Manual* then enter the IP of your hub and port `3030` if youre running the app, or `8080` if youre using the 
commandline tool.

Press save. 

Now on the mobile device is routing all its traffic to the proxy, go to safari/chrome on the mobile phone and enter 
the following url into the browser `mitm.it`. 

If you're not connected to the proxy you'll see a error message about how you need to be going through mitmproxy before 
able to download the certificate. Otherwise go ahead and select the logo for the device youre on then proceed to install 
the certificate for mitmproxy to the mobile device.

Once you're certificate is installed you'll finally need to trust it on the mobile device. 
On iOS go to settings > About > Certificate Trust Settings > Select trust on the newly installed certificate.

Your mobile device is now configured to use the proxy! :D 


## API

Base path: `<IP>:<PORT>/api/v1`

### Rules

Path: `/rules`

Verb: *GET*

Example: `curl -GET localhost:3333/api/v1/rules`

Response:
```
[
  {
    "cycle": "request",
    "rule_type": "redirect",
    "meta_data": {
      "host_ip": "example.com",
      "host_path": "/",
      "target_ip": "httpbin.org",
      "target_path": "/anything",
      "target_scheme": "http",
      "target_port": 80
    },
    "id": "16cbceca-8298-40bd-b8cb-455edd006321"
  }
]
```
Path: `/file_name?file=/tmp/proxy.txt&file=/tmp/proxy1.txt`

Verb: *GET*

Example: `curl -X GET "http://0.0.0.0:3333/api/v1/logs/get/proxy123.txt%2C%20fw.txt%2C%20freewheel.txt`

Response:
```
{
    "freewheel.txt": "<adResponse networkId='384776' version='1'>.......,
    "proxy123.txt": "FileNotFoundError"
}

```

Path: `/rules/create/redirect`

Verb: *POST*

Notes: Once this request is executed its currently configured to start printing all the response bodies out the terminal.
This is helpful for looking at the traffic but it can easily start dumping a lot of information very quickly. In
retrospect to this, there will be error for `unable to decode a byte`, this is because some response bodies dump out
heavy binary streams, in which for one, is un readable, and second can cause the proxy to crash because we are trying to print
out so much of the binary we simply just cant keep up! Please just ignore this error message
and move on with your traffic sniffing :)

Example Schema:
```
{
  "host_ip": "analytics.xcal.tv",
  "host_path": "/comcast/player",
  "target_ip": "10.169.255.6",
  "target_path": "/post_message/data",
  "target_scheme": "http",
  "target_port": 5000,
  "cycle": "request"
}
```

Response: `Success`



Path: `logs/response" `

Verb: *POST*

Notes: Once this request is executed its currently configured to start looking SUBSTRING all the response bodies out the terminal and
log response into .txt file specified by user. By default file = '/tmp/proxy.txt'. There will be error for `unable to decode a byte`,
this is because some response bodies dump out


Example Schema:
```
{
  "key_string": "adResponse networkId",
  "file_name": "fw.txt"
}
```


Path: `/logs/remove/{file}`

Verb: *DELETE*

Response: `Success`


Path: `/rules/delete/{id}`

Verb: *DELETE*

Example:
```
curl -X DELETE "http://0.0.0.0:3333/api/v1/rules/delete/16cbceca-8298-40bd-b8cb-455edd006321" -H "accept: application/json"
```

Response: `Success`

