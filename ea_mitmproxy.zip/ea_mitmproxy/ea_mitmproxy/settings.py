"""
Settings for proxy and flask api
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

# Flask settings
FLASK_SERVER_NAME = 'localhost:8888'
FLASK_HOST = '0.0.0.0'
FLASK_PORT = 3333
FLASK_DEBUG = False  # Do not use debug mode in production

# Flask-restplus settings
RESTPLUS_SWAGGER_UI_DOC_EXPANSION = 'list'
RESTPLUS_VALIDATE = True
RESTPLUS_MASK_SWAGGER = False
RESTPLUS_ERROR_404_HELP = False

# Proxy settings
PROXY_HOST = '0.0.0.0'
PROXY_PORT = 3030
