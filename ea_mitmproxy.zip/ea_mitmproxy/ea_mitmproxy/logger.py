"""
Logging module for whole project
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""
import logging
import coloredlogs

logging.basicConfig(format='%(asctime)s,%(msecs)d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d:%H:%M:%S',
                    level=logging.DEBUG)
log = logging.getLogger(__name__)
coloredlogs.install(level='INFO', logger=log)
