"""
Main app for starting both server and proxy.
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""
from flask import Flask, Blueprint
from flask_cors import CORS
from ea_mitmproxy import settings
from ea_mitmproxy.api.restplus import api
from ea_mitmproxy.logger import log
from ea_mitmproxy.api.proxy.handlers import proxy
from ea_mitmproxy.api.proxy.endpoints.rules import ns as rules_namespace
from ea_mitmproxy.api.proxy.endpoints.admin import ns as admin_namespace
from ea_mitmproxy.api.proxy.endpoints.logs import ns as logs_namespace
from queue import Queue

from threading import Thread
import emoji

app = Flask(__name__)
blueprint = Blueprint('api', __name__, url_prefix='/api/v1')
queue = Queue()


def configure_app(flask_app):
    """
    Configuration for flask app
    :param flask_app: Flask app object
    :return: Void
    """
    flask_app.config['SWAGGER_UI_DOC_EXPANSION'] = settings.RESTPLUS_SWAGGER_UI_DOC_EXPANSION
    flask_app.config['RESTPLUS_VALIDATE'] = settings.RESTPLUS_VALIDATE
    flask_app.config['RESTPLUS_MASK_SWAGGER'] = settings.RESTPLUS_MASK_SWAGGER
    flask_app.config['ERROR_404_HELP'] = settings.RESTPLUS_ERROR_404_HELP


def initialize_app(flask_app):
    """
    Initialize app and its blueprints / namespaces
    :param flask_app: Flask app object
    :return: Void
    """
    configure_app(flask_app)
    api.init_app(blueprint)
    cors = CORS(blueprint, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
    cors = CORS(flask_app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
    api.add_namespace(rules_namespace)
    api.add_namespace(admin_namespace)
    api.add_namespace(logs_namespace)
    flask_app.register_blueprint(blueprint)
    proxy.init_proxy(listen_host=settings.PROXY_HOST, listen_port=settings.PROXY_PORT)
    return flask_app


def run_flask():
    """
    Start the flask server
    :return: Void
    """
    app.run(debug=settings.FLASK_DEBUG, host=settings.FLASK_HOST, port=settings.FLASK_PORT)


def run_proxy():
    """
    Start the proxy server
    :return: Void
    """
    proxy.run()


def main():
    """
    Main process
    :return: Void
    """
    initialize_app(app)
    log.info(emoji.emojize('Swagger Page located :point_right: http://{}:{}/api/v1'.
                           format(settings.FLASK_HOST, settings.FLASK_PORT), use_aliases=True))

    flask_thread = Thread(target=run_flask)
    flask_thread.setDaemon(True)
    try:
        flask_thread.start()
        run_proxy()
    except (KeyboardInterrupt, Exception) as e:
        log.error("Exiting Proxy API")
        proxy.__exit__()
        exit(0)


if __name__ == "__main__":
    log.info(emoji.emojize(":man_mage: :man_mage: :man_mage: :man_mage:  EA PROXY :man_mage: :man_mage: "
                           ":man_mage: :man_mage:"))
    main()
