
from ea_mitmproxy.logger import log
import subprocess
import sys
import os
import requests
from time import sleep
import signal
import unittest


class TestAPI(unittest.TestCase):

    def test_get_rules(self):
        resp = requests.get('http://0.0.0.0:3333/api/v1/rules')
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json(), [])

    def test_post_rules(self):
        mock = {
                "host_ip": "analytics.xcal.tv",
                "host_path": "/comcast/player",
                "target_ip": "10.169.255.6",
                "target_path": "/post_message/data",
                "target_scheme": "http",
                "target_port": 5000,
                "cycle": "request"
                }
        resp = requests.post('http://0.0.0.0:3333/api/v1/rules/create/redirect', json=mock)
        self.assertEqual(resp.status_code, 200)
        resp = requests.get('http://0.0.0.0:3333/api/v1/rules')
        self.assertEqual(resp.status_code, 200)
        host_ip = resp.json()[0]['meta_data']['host_ip']
        self.assertEqual(host_ip, mock['host_ip'])

    def test_post_log_rules(self):
        mock = {
              "key_string": "test string",
              "file_name": "/tmp/proxy.txt"
                }
        resp = requests.post('http://0.0.0.0:3333/api/v1/rules/create/logs', json=mock)
        self.assertEqual(resp.status_code, 200)
        resp = requests.get('http://0.0.0.0:3333/api/v1/rules')
        self.assertEqual(resp.status_code, 200)
        host_ip = resp.json()[0]['meta_data']['key_string']
        self.assertEqual(host_ip, mock['key_string'])

    def test_delete_rules(self):
        mock = {
            "host_ip": "analytics.xcal.tv",
            "host_path": "/comcast/player",
            "target_ip": "10.169.255.6",
            "target_path": "/post_message/data",
            "target_scheme": "http",
            "target_port": 5000,
            "cycle": "request"
        }
        resp = requests.post('http://0.0.0.0:3333/api/v1/rules/create/redirect', json=mock)
        resp_get = requests.get('http://0.0.0.0:3333/api/v1/rules')
        id = resp_get.json()[0]['id']
        resp_delete = requests.delete('http://0.0.0.0:3333/api/v1/rules/delete/{}'.format(id))
        self.assertEqual(resp_delete.status_code, 200)


if __name__ == '__main__':
    process = subprocess.Popen(['python3 ../app.py'], stdout=subprocess.PIPE, shell=True)
    sleep(5)
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(TestAPI))
    runner = unittest.TextTestRunner()
    rc = not runner.run(suite).wasSuccessful()
    if process.pid > 1:
        os.kill(process.pid, signal.SIGTERM)
        log.info('process killed')
    sys.exit(rc)
