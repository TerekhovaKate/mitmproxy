"""
API namespace for managing the proxy interface.
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

from flask_restplus import Resource
from ea_mitmproxy.api.restplus import api
from ea_mitmproxy.api.proxy.handlers import proxy
from ea_mitmproxy.logger import log

# Define a namespace. All paths will be prefixed with /api/v1/rules
ns = api.namespace('admin', description='Manage admin functionality with the proxy')


@ns.route('/shutdown')
class ProxyShutdown(Resource):

    @api.response(200, 'Successfully shutdown the proxy')
    def post(self):
        """
        Create a redirect rule
        """
        try:
            proxy.shutdown()
        except Exception as e:
            log.error("Failed to shutdown")
            return 'Error', 500

        return 'Success', 200


@ns.route('/start')
class ProxyShutdown(Resource):

    @api.response(200, 'Successfully start the proxy')
    def post(self):
        """
        Create a redirect rule
        """
        try:
            proxy.run()
        except Exception as e:
            log.error("Failed to start the proxy")
            return 'Error', 500

        return 'Success', 200
