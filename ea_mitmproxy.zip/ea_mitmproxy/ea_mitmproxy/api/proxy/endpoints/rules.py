"""
API namespace for managing rules within the proxy interface.
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

from flask_restplus import Resource
from flask import request
from ea_mitmproxy.api.restplus import api
from ea_mitmproxy.api.proxy.serializers import redirect
from ea_mitmproxy.api.proxy.handlers import redirect_request_handler
from ea_mitmproxy.api.proxy.handlers import proxy
from ea_mitmproxy.logger import log

# Define a namespace. All paths will be prefixed with /api/v1/rules
ns = api.namespace('rules', description='Manage new proxy rules')

# Create a new redirect rule using the redirect_handler
# We can add and make more complex handlers as we see fit.


@ns.route('/create/redirect')
class ProxyAddonCreate(Resource):

    @api.response(200, 'Successfully create a rule')
    @api.expect(redirect)
    @api.doc(redirect)
    def post(self):
        """
        Create a redirect rule
        :host_ip: The IP of the request you want to intercept
        :host_path: The path of the request you want to intercept
        :target_ip: The IP which you want to redirect the host_ip to
        :target_path: The path of the which you want to redirect the original to
        :target_scheme: This will either be HTTP or HTTPS
        :target_port: The port for which you want to redirect to, HTTP will be 80 and HTTPS will be 443
        """
        data = request.json
        try:
            redirect_request_handler(json=data)
        except Exception as e:
            log.error("Failed to create a new rule", e)
            return 'Error', 500

        return 'Success', 200

# Get all the rules that we have stored in memory with the proxy interface
@ns.route('')
class ProxyAddon(Resource):

    @api.response(200, 'Successfully get all rules')
    def get(self):

        """
        Get all rules
        :return:
        """
        try:
            addons = proxy.get_addons()
        except Exception as e:
            log.error("Failed to get all rules")
            return 'error', 500
        return addons, 200


# Delete a rule from the in-memory proxy store.
@ns.route('/delete/<string:id>')
class ProxyAddonDelete(Resource):

    @api.response(200, 'Successfully delete a rule')
    @api.response(500, 'Internal Error')
    def delete(self, id):
        """
        Delete a rule
        :return:
        """
        try:
            proxy.remove_addon(id)
        except Exception as e:
            return 'Error', 500

        return 'Success', 200

@ns.route('/delete/all')
class ProxyAddonDelete(Resource):

    @api.response(200, 'Successfully delete a rule')
    @api.response(500, 'Internal Error')
    def delete(self):
        """
        Delete a rule
        :return:
        """
        try:
            proxy.remove_all_addon()
        except Exception as e:
            return 'Error', 500

        return 'Success', 200
