
"""
API namespace for managing rules within the proxy interface.
Developers: Viper EA team
"""

from flask import request
from flask_restplus import Resource, reqparse

from ea_mitmproxy.api.proxy.handlers import redirect_logger, get_file_content, delete_file, modify_context_values
from ea_mitmproxy.api.proxy.serializers import content, context
from ea_mitmproxy.api.restplus import api
from ea_mitmproxy.logger import log

# Define a namespace. All paths will be prefixed with /api/v1/logs
ns = api.namespace('logs', description='Manage proxy log response rules', ordered=True)

parser = reqparse.RequestParser()
parser.add_argument('path', type=str, help='Path to file')
parser.add_argument('file', type=str, help='file or files with "," separator')


@ns.route('/get')
class ProxyAddonContent(Resource):


    @api.response(200, 'Successfully get all file content')
    @api.response(500, 'Internal Error')
    @api.expect(parser)
    def get(self):
        """
        Get log file content
        :file: string of files : proxy123.txt, fw.txt, response.txt
        :return: json object with file content
        """

        try:
            params = parser.parse_args()

            file_content = get_file_content(params)
        except Exception as e:
            log.error("Failed to get file content", e)
            return 'Error', 500

        return file_content, 200


@ns.route('/response')
class ProxyAddonLogs(Resource):

    @api.response(200, 'Successfully create a log rule')
    @api.expect(content)
    @api.doc(content)
    def post(self):
        """
        Create a logs rule
        :key_string': The key substring searching for
        :file_name': The file name to store data. None: log storage location /tmp

        """
        data = request.json
        try:
            redirect_logger(json=data)
        except Exception as e:
            log.error("Failed to create a new rule", e)
            return 'Error', 500

        return 'Success', 200

@ns.route('/modify_context')
class ProxyAddonContext(Resource):

    @api.response(200, 'Successfully create a log rule')
    @api.expect(context)
    @api.doc(context)
    def post(self):
        """
        Modify request content to client
        :target_ip: The IP of the request you want to intercept = "5df09.v.fwmrm.net",
        :target_path: The path of the which you want to redirect the original to = "/ad/p/1"
        :old_value: string -> value to replace = 384777:xtv_TVE_vod_ios"
        :new_value: string -> new value for client = 384776:xtv_TVE_vod_ios"

        """
        data = request.json
        try:
            modify_context_values(json=data)
        except Exception as e:
            log.error("Failed to create a new rule", e)
            return 'Error', 500

        return 'Success', 200


# Delete a file from  proxy /tmp store.
@ns.route('/remove/file')
class ProxyAddonDelete(Resource):

    @api.response(200, 'Successfully delete a file')
    @api.response(500, 'Internal Error')
    @api.expect(parser)
    def delete(self):
        """
        Delete a log file
        :file: string of files : proxy123.txt, fw.txt, response.txt
        :return:
        """
        try:
            params = parser.parse_args()
            files = delete_file(params)
        except Exception as e:
            log.error("Failed to delete file", e)
            return 'Error', 500

        return files, 200
