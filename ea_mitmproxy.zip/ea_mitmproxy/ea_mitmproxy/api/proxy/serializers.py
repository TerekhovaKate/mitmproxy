"""
Serializer for API requests
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

from flask_restplus import fields

from ea_mitmproxy.api.restplus import api

redirect = api.model('Redirect', {
    'host_ip': fields.String(required=True),
    'host_path': fields.String(required=True),
    'target_ip': fields.String(required=True),
    'target_path': fields.String(required=True),
    'target_scheme': fields.String(required=True),
    'target_port': fields.Integer(required=True, default=80),
})

content = api.model('Content', {
    'key_string': fields.String(required=True),
    'file_name': fields.String(required=False, default=None),
})

context = api.model('Context', {
    'target_ip': fields.String(required=True),
    'target_path': fields.String(required=False),
    'old_value': fields.String(required=True),
    'new_value': fields.String(required=True),
})