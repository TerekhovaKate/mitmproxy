"""
API handlers to create our proxy rules.
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

import os
import random
import re

from mitmproxy import http

from ea_mitmproxy.api.proxy.proxy import Proxy
from ea_mitmproxy.logger import log

# Create our proxy object to use for each handler request. This object needs to be here to work.
proxy = Proxy()

def redirect_logger(json):
    """
    This handler can be used for logging response to file
    :param json: is a dict containing the information for what we want to happen with the proxy.
    :return: None
    """

    try:
        key_string = json['key_string']
        file_name =json['file_name']

        content_id = 'content' + str(random.randint(1, 100))

        def init(self):
            """
            Init function for the proxy rule
            """
            self.key_string = key_string
            self.file_name = file_name
            self.rule_type = 'content'
            self.cycle = 'request'


        def writefile(self, filename, content):
            log.error("Writing File: {}".format(filename))
            with open(filename, "wb") as f:
                f.write(content)
            f.close()

        def response(self, flow: http.HTTPFlow):

            file_name = self.file_name

            data = flow.response.content.decode('utf8')

            if data.find(self.key_string) != -1:

                print("="*50)
                log.info(data)
                print(flow.request.method + " " + flow.request.path + " " + flow.request.http_version)
                print("-"*50 + "request headers:")
                if file_name is None:
                    file_name = "/tmp/proxy.txt"

                self.writefile(file_name, flow.response.content)

        # Create a new addon object

        new_class = type(content_id, (object,), {
            "__init__": init,
            "writefile": writefile,
            "response": response
        })

        # Add the new rule to the proxy.

        instance = new_class()
        proxy.new_addon(instance, json)
    except Exception as e:
        log.error("Failed to add redirect handler")
        log.error("Error: {}".format(e))
    return

def redirect_request_handler(json):
    """
    This handler can be used for a simple redirect
    :param json: is a dict containing the information for what we want to happen with the proxy.
    :return: None
    """
    try:
        target_ip = json['target_ip']
        target_path = json['target_path']
        target_scheme = json['target_scheme']
        target_port = json['target_port']
        host_ip = json['host_ip']
        host_path = json['host_path']

        # Object names to need to randomly generated. No two objects can have the same name in the proxy.
        # useful for using multiple redirect rules with the same proxy.
        redirect_id = 'redirect' + str(random.randint(1, 100))

        def init(self):
            """
            Init function for the proxy rule
            """
            self.target_ip = target_ip
            self.target_path = target_path
            self.target_scheme = target_scheme
            self.target_port = target_port
            self.host_ip = host_ip
            self.host_path = host_path
            self.rule_type = 'redirect'
            self.cycle = 'request'

        def writefile(self, filename, content):
            """
            Write the response to a file
            :param self: Proxy object
            :param filename:  the filename.. hardcoded for now
            :param content: the response body of the request.
            :return:
            """
            log.info("Writing File: {}".format(filename))
            with open(filename, "a+b") as f:
                f.write(content)
            f.close()

        def request(self, flow: http.HTTPFlow) -> None:
            """
            This request function will redirect to a given URL based on the target and host.
            :param self: Proxy object
            :param flow: mitmproxy api http object
            :return:
            """
            # pretty_host takes the "Host" header of the request into account,
            # which is useful in transparent mode where we usually only have the IP
            # otherwise.
            log.info("handle request for: %s%s" % (flow.request.host, flow.request.path))

            if flow.request.pretty_host.find(self.host_ip) != -1:
                print("="*50)
                print(flow.request.method + " " + flow.request.path + " " + flow.request.http_version)
                print("-"*50 + "request headers:")

                for k, v in flow.request.headers.items():
                    print("%-20s: %s" % (k.upper(), v))
                print(flow.request.content.decode('utf-8'))
                flow.request.host = self.target_ip
                if self.target_port != 0:
                    flow.request.port = self.target_port
                flow.request.path = self.target_path
                flow.request.scheme = self.target_scheme

        def response(self, flow: http.HTTPFlow) -> None:
            """
            Write the response body to a file.
            :param self: Proxy object
            :param flow: mitmproxy api http object
            :return:
            """
            if flow.request.pretty_host.find(self.target_ip) != -1:
                print(flow.request.method + " " + flow.request.path + " " + flow.request.http_version)
                print("-" * 50 + "request headers:")
                print(flow.response.content.decode('utf-8'))
                for k, v in flow.request.headers.items():
                    print("%-20s: %s" % (k.upper(), v))
                print("-" * 50 + "response headers:")
                for k, v in flow.response.headers.items():
                    print("%-20s: %s" % (k.upper(), v))
                    print(flow.response.content.decode('utf-8'))

        # Create a new addon object
        new_class = type(redirect_id, (object,), {
            "__init__": init,
            "request": request,
            "writefile": writefile,
            "response": response
        })

        # Add the new rule to the proxy.
        instance = new_class()
        proxy.new_addon(instance, json)
    except Exception as e:
        log.error("Failed to add redirect handler")
        log.error("Error: {}".format(e))
    return

def modify_context_values(json):
    """
    This handler can be used for replace values in request
    :param json: is a dict containing the information for what we want to happen with the proxy.
    :return: None
    """
    try:
        target_ip = json['target_ip']
        target_path = json['target_path']
        old_value = json['old_value']
        new_value = json['new_value']


        # Object names to need to randomly generated. No two objects can have the same name in the proxy.
        # useful for using multiple redirect rules with the same proxy.
        redirect_id = 'redirect' + str(random.randint(1, 100))

        def init(self):
            """
            Init function for the proxy rule
            """
            self.target_ip = target_ip
            self.target_path = target_path
            self.old_value = old_value
            self.new_value = new_value
            self.rule_type = 'context'
            self.cycle = 'request'

        def writefile(self, filename, content):
            """
            Write the response to a file
            :param self: Proxy object
            :param filename:  the filename.. hardcoded for now
            :param content: the response body of the request.
            :return:
            """
            log.info("Writing File: {}".format(filename))
            with open(filename, "a+b") as f:
                f.write(content)
            f.close()

        def request(self, flow: http.HTTPFlow) -> None:
            """
            This request function will redirect to a given URL based on the target and host.
            :param self: Proxy object
            :param flow: mitmproxy api http object
            :return:
            """
            # pretty_host takes the "Host" header of the request into account,
            # which is useful in transparent mode where we usually only have the IP
            # otherwise.
            log.info("handle request for: %s%s" % (flow.request.host, flow.request.path))


            print("=" * 50)
            print(flow.request.method + " " + flow.request.path + " " + flow.request.http_version)
            print(flow.request.content.decode('utf-8'))
            print(flow.request.pretty_host.find(self.target_path))

            if flow.request.pretty_host.find(self.target_ip) != -1 or \
                    flow.request.pretty_host.find(self.target_path) != -1:
                flow.request.content = flow.request.content.replace(self.old_value.encode(),
                                                                  self.new_value.encode())

            print("-" * 50 + "request headers:")

            for k, v in flow.request.headers.items():
                print("%-20s: %s" % (k.upper(), v))
            print(flow.request.content.decode('utf-8'))

        # Create a new addon object
        new_class = type(redirect_id, (object,), {
            "__init__": init,
            "request": request,
            "writefile": writefile,
        })

        # Add the new rule to the proxy.
        instance = new_class()
        proxy.new_addon(instance, json)
    except Exception as e:
        log.error("Failed to add redirect handler")
        log.error("Error: {}".format(e))
    return

def get_file_content(file):
    """
    :file: string of files example -> proxy123.txt, fw.txt, response.txt
    :return: dictionary
    """
    log.debug(file)

    file_list = remove_punctuation(file["file"])
    contents = {}
    for i in file_list:
        try:
            path = str(file["path"])+'/'+str(i)
            with open(path, 'r') as data:
                contents[i] = data.read()
        except FileNotFoundError:
            contents[i] = 'FileNotFoundError'
    return contents

def delete_file(file):
    """
    :file: string of files example -> proxy123.txt, fw.txt, response.txt
    :return: list
    """
    file_list = remove_punctuation(file["file"])
    removed ={}
    for x in file_list:

        if os.path.exists(str(file["path"]) + '/' + str(x)):
            removed[x]= os.path.exists(str(file["path"]) + '/' + str(x))
            os.remove(str(file["path"]) + '/' + str(x))
        else:
            removed[x] = 'FileNotFoundError'
    return removed

def remove_punctuation(file):
    data_string = re.sub(r'[!:;,?"]+', '', file)
    file_list = data_string.split(" ")
    return file_list






