"""
Proxy object for all proxy associated operations.
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""

import uuid
import emoji
from mitmproxy import proxy, options
from mitmproxy.tools.dump import DumpMaster
from mitmproxy.addons import block
from mitmproxy.proxy.protocol import Layer
from ea_mitmproxy.logger import log


class Proxy:
    def __init__(self):
        """
        Initialize the Proxy Object
        """
        self.addons = [
            block,
        ]
        self.listen_host = None
        self.listen_port = None
        self.mode = None
        self.opts = None
        self.proxy_conf = None
        self.master = None
        self.addon_control = {}


    def __enter__(self):
        pass

    def __exit__(self):
        """
        For a clean exit with the proxy.
        """
        log.info("Shutting down proxy server")
        self.shutdown()

    def init_proxy(self, listen_host='0.0.0.0', listen_port=3030, mode='regular'):
        """
        initialize mitmproxy api's
        :param listen_host: host of poxy
        :param listen_port: port to listen on
        :param mode: proxy mode, can be changed between regular and transparent
        :return:
        """
        log.info("Proxy being initialized.....")
        self.listen_host = listen_host
        self.listen_port = listen_port
        self.mode = mode
        self.opts = options.Options(listen_host=self.listen_host, listen_port=self.listen_port, mode=self.mode,
                                    http2=False)
        self.proxy_conf = proxy.config.ProxyConfig(self.opts)
        self.master = DumpMaster(self.opts)
        self.master.server = proxy.server.ProxyServer(self.proxy_conf)
        self.master.addons.add(self.addons)
        log.info("Proxy configured")

    def run(self):
        """
        Start the proxy server
        :return:
        """
        log.info(emoji.emojize('Proxy is listening on :point_right: http://{}:{}'
                               .format(self.listen_host, self.listen_port), use_aliases=True))
        self.master.run()

    def shutdown(self):
        """
        Shutdown the proxy server
        """
        self.master.shutdown()
        log.info("successfully shutdown... see you next time :)")
        return

    def new_addon(self, addon, meta=None):
        """
        Add a new rule to the proxy
        :param addon: Generated proxy class based from user request.
        :param meta: Meta data about a rule requested from the user.
        :return:
        """
        if meta:
            self.addon_control[type(addon).__name__] = {
                'id': str(uuid.uuid4()),
                'meta_data': meta,
                'addon': addon
            }
        log.info("Adding new proxy rule")
        self.addons.append(addon)
        self.__add_rule(addon)

    def __add_rule(self, addon):
        """
        Add the rule
        :param addon:  Generated class
        :return:
        """
        self.master.addons.add(addon)

    def get_addons(self):
        """
        Get all current rules.
        :return:
        """
        log.info("Getting all addons")
        addons = []
        for i in self.addon_control:
            addon = {
                'cycle': self.addon_control[i]['addon'].cycle,
                'rule_type': self.addon_control[i]['addon'].rule_type,
                'meta_data': self.addon_control[i]['meta_data'],
                'id': str(self.addon_control[i]['id'])

            }
            addons.append(addon)
        return addons

    def remove_addon(self, id):
        """
        Remove a proxy rule from the proxy
        :param id: uuid generated from creating a new rule
        :return:
        """
        try:
            addon = None
            for i in self.addon_control:
                log.info(self.addon_control[i])
                if self.addon_control[i]['id'] == id:
                    addon = self.addon_control[i]['addon']

            if addon is None:
                raise Exception("No rule found with the given uuid")

            self.master.addons.remove(addon)

            for i in self.addon_control:
                if self.addon_control[i]['id'] == id:
                    del self.addon_control[i]
                    break

        except Exception as e:
            log.error("Unable to remove the rule")
            log.error('Error: {}'.format(e))


    def remove_all_addon(self):
        """
        Remove a proxy rule from the proxy
        :return:
        # """
        try:
            for i in self.addon_control:
                log.info(self.addon_control[i])
                self.master.addons.remove(self.addon_control[i]['addon'])

            self.addon_control.clear()


        except Exception as e:
            log.error("Unable to remove the rule")
            log.error('Error: {}'.format(e))









