"""
Create our API object for flask rest_plus
Developers: Viper EA team
Date (last edit): September 4th, 2019
"""
from flask_restplus import Api
api = Api(version='1.0', title='EA MITM PROXY',
          description='Man in the middle proxy for SSPC')
